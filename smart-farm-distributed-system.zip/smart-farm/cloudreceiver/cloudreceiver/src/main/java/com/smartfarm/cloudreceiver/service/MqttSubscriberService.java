package com.smartfarm.cloudreceiver.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartfarm.cloudreceiver.model.SensorPayload;
import jakarta.annotation.PostConstruct;
import org.eclipse.paho.client.mqttv3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class MqttSubscriberService implements MqttCallback {

    private static final Logger log = LoggerFactory.getLogger(MqttSubscriberService.class);

    private final MqttClient mqttClient;
    private final KafkaTemplate<String, SensorPayload> kafkaTemplate;
    private final InfluxWriterService influxWriter; 
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${mqtt.topic}")
    private String topic;
    
    public MqttSubscriberService(MqttClient mqttClient,
            KafkaTemplate<String, SensorPayload> kafkaTemplate,
            InfluxWriterService influxWriter) {   // ← add parameter
    		this.mqttClient = mqttClient;
    		this.kafkaTemplate = kafkaTemplate;
    		this.influxWriter = influxWriter;   // ← assign it
    }

    @PostConstruct
    public void subscribe() throws MqttException {
        mqttClient.setCallback(this);
        mqttClient.subscribe("farm/+/sensor/#", 1);   // sensor data
        mqttClient.subscribe("farm/+/heartbeat", 1);   // heartbeats
        log.info("Subscribed to sensor and heartbeat topics");
    }

    @Override
    public void messageArrived(String topic, MqttMessage message) {
        try {
            String json = new String(message.getPayload());

            if (topic.contains("/heartbeat")) {
                handleHeartbeat(topic, json);
            } else if (topic.contains("/sensor/")) {
                SensorPayload payload = objectMapper.readValue(json, SensorPayload.class);
                kafkaTemplate.send("sensor-readings", payload);
            }
        } catch (Exception e) {
            log.error("Failed to process message on {}: {}", topic, e.getMessage());
        }
    }

    private void handleHeartbeat(String topic, String json) {
        try {
            // Extract farm_id from topic: farm/001/heartbeat
            String farmId = topic.split("/")[1];
            influxWriter.writeHeartbeat(farmId);
            log.debug("Heartbeat received from farm {}", farmId);
        } catch (Exception e) {
            log.error("Failed to handle heartbeat: {}", e.getMessage());
        }
    }
    
    @Override
    public void connectionLost(Throwable cause) {
        log.warn("MQTT connection lost: {}", cause.getMessage());
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {}
}
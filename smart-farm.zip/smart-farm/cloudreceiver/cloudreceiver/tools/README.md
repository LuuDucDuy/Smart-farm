# Tools

Utility scripts for testing and simulating the Smart Farm cloud receiver.

## simulator.py

Simulates a Raspberry Pi edge node publishing sensor data via MQTT.
Mirrors the contract the real edge node will follow:
- QoS 1 publishing
- ISO 8601 timestamps
- One message per sensor (temperature, humidity, soil moisture)
- Topic format: `farm/{farm_id}/sensor/{type}`

### Requirements
- Python 3.9+
- `pip install paho-mqtt`

### Usage
```bash
python simulator.py
```

Publishes a new reading for all three sensors every 5 seconds.
Press Ctrl+C to stop.

### Configuration
Edit the constants at the top of `simulator.py`:
- `BROKER` — MQTT broker address (default: `localhost`)
- `PORT` — MQTT broker port (default: `1883`)
- `FARM_ID` — farm identifier (default: `001`)
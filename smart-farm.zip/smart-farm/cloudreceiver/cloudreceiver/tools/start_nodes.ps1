$simulator = "C:\smart-farm\cloudreceiver\cloudreceiver\tools\edge_simulator_fixed.py"

Write-Host "Starting 3 edge nodes..." -ForegroundColor Green

# Node 1
Start-Process powershell -ArgumentList @(
    "-NoExit",
    "-Command",
    "& { `$env:FARM_ID = '001'; `$env:STATION_ID = 'node-1'; Write-Host 'Starting node-1 (farm 001)'; python '$simulator' }"
)

# Node 2
Start-Process powershell -ArgumentList @(
    "-NoExit",
    "-Command",
    "& { `$env:FARM_ID = '002'; `$env:STATION_ID = 'node-2'; Write-Host 'Starting node-2 (farm 002)'; python '$simulator' }"
)

# Node 3
Start-Process powershell -ArgumentList @(
    "-NoExit",
    "-Command",
    "& { `$env:FARM_ID = '003'; `$env:STATION_ID = 'node-3'; Write-Host 'Starting node-3 (farm 003)'; python '$simulator' }"
)

Write-Host "All 3 nodes started in separate windows." -ForegroundColor Green
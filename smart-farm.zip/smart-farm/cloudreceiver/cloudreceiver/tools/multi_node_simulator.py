"""
multi_node_simulator.py

Simulates N edge nodes inside a single Python process using asyncio.
"""

import asyncio
import json
import random
import argparse
from datetime import datetime, timezone
from paho.mqtt import client as mqtt_client


class SimulatedNode:
    """One logical edge node — has its own farm_id and state."""

    def __init__(self, farm_id, mqtt_client, soil_dry=30):
        self.farm_id = farm_id
        self.client = mqtt_client
        self.soil_dry = soil_dry
        self.pump_on = False
        self.cmd_topic = f"farm/{farm_id}/control/pump"
        self.temp_base = 25 + random.uniform(-3, 3)
        self.humid_base = 60 + random.uniform(-10, 10)
        self.soil_base = 40 + random.uniform(-10, 10)

    def on_pump_command(self, command):
        if command == "pump_on":
            self.pump_on = True
            print(f"[farm-{self.farm_id}] Pump ON (cloud override)")
        elif command == "pump_off":
            self.pump_on = False
            print(f"[farm-{self.farm_id}] Pump OFF (cloud override)")

    def publish_sensor(self, sensor_id, sensor_type, value, unit):
        payload = {
            "sensor_id": sensor_id,
            "farm_id": self.farm_id,
            "value": round(value, 1),
            "unit": unit,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        topic = f"farm/{self.farm_id}/sensor/{sensor_type}"
        self.client.publish(topic, json.dumps(payload), qos=1)

    def publish_heartbeat(self):
        topic = f"farm/{self.farm_id}/heartbeat"
        payload = {"status": "alive", "timestamp": int(datetime.now().timestamp())}
        self.client.publish(topic, json.dumps(payload), qos=1)

    async def run_sensors(self):
        while True:
            temp = self.temp_base + random.uniform(-5, 5)
            humid = self.humid_base + random.uniform(-10, 10)
            soil = self.soil_base + random.uniform(-15, 15)

            if soil < self.soil_dry and not self.pump_on:
                self.pump_on = True
            elif soil >= self.soil_dry + 10 and self.pump_on:
                self.pump_on = False

            self.publish_sensor("temp-01", "temperature", temp, "C")
            self.publish_sensor("humid-01", "humidity", humid, "%")
            self.publish_sensor("soil-01", "soil", soil, "%")

            await asyncio.sleep(3 + random.uniform(-0.5, 0.5))

    async def run_heartbeat(self):
        while True:
            self.publish_heartbeat()
            await asyncio.sleep(5)


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--nodes", type=int, default=10)
    parser.add_argument("--broker", default="localhost")
    parser.add_argument("--port", type=int, default=1883)
    args = parser.parse_args()

    client = mqtt_client.Client(
        mqtt_client.CallbackAPIVersion.VERSION2,
        client_id=f"multi-sim-{random.randint(1000, 9999)}"
    )
    client.username_pw_set("farmuser", "farmpass123")

    nodes = {}
    for i in range(1, args.nodes + 1):
        farm_id = f"{i:03d}"
        nodes[farm_id] = SimulatedNode(farm_id, client)

    def on_message(client, userdata, msg):
        topic_parts = msg.topic.split("/")
        if len(topic_parts) >= 3 and topic_parts[2] == "control":
            farm_id = topic_parts[1]
            if farm_id in nodes:
                nodes[farm_id].on_pump_command(msg.payload.decode().strip())

    def on_connect(client, userdata, flags, reason_code, properties):
        if reason_code == 0:
            print("Connected to broker — subscribing to control topics")
            client.subscribe("farm/+/control/pump")

    client.on_connect = on_connect
    client.on_message = on_message

    client.connect_async(args.broker, args.port, 60)
    client.loop_start()

    print(f"Starting {args.nodes} simulated nodes (farm-001 to farm-{args.nodes:03d})")
    print(f"Publishing to {args.broker}:{args.port}")
    print(f"Press Ctrl+C to stop")

    tasks = []
    for node in nodes.values():
        tasks.append(asyncio.create_task(node.run_sensors()))
        tasks.append(asyncio.create_task(node.run_heartbeat()))

    try:
        await asyncio.gather(*tasks)
    except KeyboardInterrupt:
        print("\nStopping all nodes...")
        client.loop_stop()
        client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
package com.smartfarm.cloudreceiver.controller;

import com.smartfarm.cloudreceiver.service.PumpControlService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/control")
public class ControlController {

    private final PumpControlService pumpControlService;

    public ControlController(PumpControlService pumpControlService) {
        this.pumpControlService = pumpControlService;
    }

    // POST /control/pump?farmId=001&on=true
    @PostMapping("/pump")
    public Map<String, Object> controlPump(
            @RequestParam(defaultValue = "001") String farmId,
            @RequestParam boolean on) {

        pumpControlService.setPump(farmId, on);

        return Map.of(
            "status", "command sent",
            "farm_id", farmId,
            "pump", on ? "ON" : "OFF"
        );
    }
}
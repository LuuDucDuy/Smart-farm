package com.smartfarm.cloudreceiver.service;

import com.influxdb.client.InfluxDBClient;
import com.influxdb.client.WriteApiBlocking;
import com.influxdb.client.write.Point;
import com.influxdb.client.domain.WritePrecision;
import com.smartfarm.cloudreceiver.model.SensorPayload;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import org.springframework.scheduling.annotation.Scheduled;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.*;

@Service
public class InfluxWriterService {

    private static final Logger log = LoggerFactory.getLogger(InfluxWriterService.class);

    private final WriteApiBlocking writeApi;
    private final InfluxWriteGateway writeGateway;

    private final Set<String> recentIds = Collections.newSetFromMap(
        new LinkedHashMap<>() {
            protected boolean removeEldestEntry(Map.Entry<String, Boolean> e) {
                return size() > 5000;
            }
        }
    );

    public InfluxWriterService(InfluxDBClient influxDBClient, InfluxWriteGateway writeGateway) {
        this.writeApi = influxDBClient.getWriteApiBlocking();
        this.writeGateway = writeGateway;
    }

    @PostConstruct
    public void init() throws IOException {
        Files.createDirectories(Path.of("dlq"));
    }

    @KafkaListener(topics = "sensor-readings", groupId = "influx-writer",
            containerFactory = "batchFactory")
    public void consume(List<SensorPayload> batch) {
    	System.out.println(">>> CONSUME called with " + batch.size() + " messages <<<");
 
    	List<SensorPayload> clean = batch.stream()
    			.filter(this::isValid)
    			.filter(p -> {
    				String id = p.getSensorId() + p.getTimestamp();
    				synchronized (recentIds) {
    					if (recentIds.contains(id)) return false;
    					recentIds.add(id);
    					return true;
    				}
    			})
    			.toList();

    	System.out.println(">>> After filtering: " + clean.size() + " messages <<<");

    	if (!clean.isEmpty()) writeGateway.writeBatch(clean);
    }

    @CircuitBreaker(name = "influxdb", fallbackMethod = "writeToDlq")
    public void writeBatch(List<SensorPayload> batch) {
        System.out.println(">>> writeBatch called with " + batch.size() + " points <<<");
        List<Point> points = batch.stream().map(p ->
            Point.measurement("sensor_reading")
                .addTag("sensor_id", p.getSensorId())
                .addTag("farm_id", p.getFarmId())
                .addField("value", p.getValue())
                .addTag("unit", p.getUnit())
                .time(Instant.now(), WritePrecision.MS)
        ).toList();

        writeApi.writePoints(points);
        System.out.println(">>> writeBatch SUCCESS <<<");
    }

    public void writeToDlq(List<SensorPayload> batch, Exception e) {
        System.out.println(">>> writeToDlq FALLBACK TRIGGERED: " + e.getMessage() + " <<<");
        log.error("Circuit breaker open — writing {} messages to DLQ. Cause: {}",
            batch.size(), e.getMessage());
        try {
            String filename = "dlq/failed-" + System.currentTimeMillis() + ".json";
            StringBuilder json = new StringBuilder("[");
            for (int i = 0; i < batch.size(); i++) {
                SensorPayload p = batch.get(i);
                json.append(String.format(
                    "{\"sensor_id\":\"%s\",\"farm_id\":\"%s\",\"value\":%s,\"unit\":\"%s\",\"timestamp\":\"%s\"}",
                    p.getSensorId(), p.getFarmId(), p.getValue(), p.getUnit(), p.getTimestamp()
                ));
                if (i < batch.size() - 1) json.append(",");
            }
            json.append("]");
            Files.writeString(Path.of(filename), json.toString(), StandardOpenOption.CREATE);
            log.info("DLQ file written: {}", filename);
        } catch (IOException ioEx) {
            log.error("Failed to write DLQ file", ioEx);
        }
    }

    @Scheduled(fixedDelay = 60000) // runs every 60 seconds
    public void recoverDlq() {
        Path dlqDir = Path.of("dlq");
        try {
            List<Path> files = Files.list(dlqDir)
                .filter(p -> p.toString().endsWith(".json"))
                .toList();

            if (files.isEmpty()) {
                return; // nothing to recover, exit silently
            }

            log.info("DLQ recovery — found {} file(s) to retry", files.size());

            ObjectMapper mapper = new ObjectMapper();

            for (Path file : files) {
                try {
                    String content = Files.readString(file);
                    List<SensorPayload> batch = mapper.readValue(
                        content,
                        mapper.getTypeFactory()
                            .constructCollectionType(List.class, SensorPayload.class)
                    );
                    writeGateway.writeBatch(batch);
                    Files.delete(file); // only deletes if writeBatch succeeded
                    log.info("DLQ recovery succeeded — deleted: {}", file.getFileName());
                } catch (Exception e) {
                    log.warn("DLQ recovery failed for {} — will retry next cycle: {}",
                        file.getFileName(), e.getMessage());
                    // intentionally leave file for next 60s cycle
                }
            }

        } catch (IOException e) {
            log.error("Failed to scan DLQ directory: {}", e.getMessage());
        }
    }
    
    public void writeHeartbeat(String farmId) {
        Point point = Point.measurement("node_heartbeat")
            .addTag("farm_id", farmId)
            .addField("alive", 1)
            .time(Instant.now(), WritePrecision.MS);
        writeApi.writePoint(point);
    }
    
    private boolean isValid(SensorPayload p) {
        if (p.getSensorId() == null || p.getValue() == null || p.getTimestamp() == null)
            return false;
        if ("C".equals(p.getUnit()) && (p.getValue() < -50 || p.getValue() > 100))
            return false;
        return true;
    }
   
}
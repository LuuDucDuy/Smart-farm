package com.smartfarm.cloudreceiver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class CloudreceiverApplication {

    public static void main(String[] args) {
        SpringApplication.run(CloudreceiverApplication.class, args);
    }
}
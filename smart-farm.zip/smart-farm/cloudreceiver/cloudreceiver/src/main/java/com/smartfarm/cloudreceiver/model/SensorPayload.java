package com.smartfarm.cloudreceiver.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SensorPayload {

    @JsonProperty("sensor_id")
    private String sensorId;

    @JsonProperty("farm_id")
    private String farmId;

    private Double value;
    private String unit;
    private String timestamp;

    // Getters and setters
    public String getSensorId() { return sensorId; }
    public void setSensorId(String sensorId) { this.sensorId = sensorId; }

    public String getFarmId() { return farmId; }
    public void setFarmId(String farmId) { this.farmId = farmId; }

    public Double getValue() { return value; }
    public void setValue(Double value) { this.value = value; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }
}
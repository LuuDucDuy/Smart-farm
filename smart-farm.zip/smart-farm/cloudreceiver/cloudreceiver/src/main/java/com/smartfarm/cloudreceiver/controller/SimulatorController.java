package com.smartfarm.cloudreceiver.controller;

import com.smartfarm.cloudreceiver.model.SensorPayload;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Map;
import java.util.Random;

@RestController
@RequestMapping("/simulate")
public class SimulatorController {

    private final KafkaTemplate<String, SensorPayload> kafkaTemplate;
    private final Random random = new Random();

    public SimulatorController(KafkaTemplate<String, SensorPayload> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    // POST /simulate/reading - single sensor reading
    @PostMapping("/reading")
    public Map<String, Object> simulateReading(
            @RequestParam(defaultValue = "temp-01") String sensorId,
            @RequestParam(defaultValue = "001") String farmId,
            @RequestParam(defaultValue = "C") String unit,
            @RequestParam(required = false) Double value) {

        SensorPayload payload = new SensorPayload();
        payload.setSensorId(sensorId);
        payload.setFarmId(farmId);
        payload.setUnit(unit);
        payload.setTimestamp(Instant.now().toString());
        
        // Use provided value, or generate random based on sensor type
        if (value != null) {
            payload.setValue(value);
        } else {
            payload.setValue(generateValue(sensorId));
        }

        kafkaTemplate.send("sensor-readings", payload);

        return Map.of(
            "status", "sent",
            "sensor_id", payload.getSensorId(),
            "value", payload.getValue(),
            "timestamp", payload.getTimestamp()
        );
    }

    // POST /simulate/burst?count=10 - generate many readings at once
    @PostMapping("/burst")
    public Map<String, Object> simulateBurst(
            @RequestParam(defaultValue = "10") int count,
            @RequestParam(defaultValue = "001") String farmId) {

        String[] sensors = {"temp-01", "humid-01", "soil-01"};
        String[] units = {"C", "%", "%"};

        for (int i = 0; i < count; i++) {
            for (int s = 0; s < sensors.length; s++) {
                SensorPayload payload = new SensorPayload();
                payload.setSensorId(sensors[s]);
                payload.setFarmId(farmId);
                payload.setUnit(units[s]);
                payload.setValue(generateValue(sensors[s]));
                payload.setTimestamp(Instant.now().toString());

                kafkaTemplate.send("sensor-readings", payload);
            }
        }

        return Map.of(
            "status", "sent",
            "total_messages", count * sensors.length,
            "sensors", sensors
        );
    }

    // Realistic value generation based on sensor type
    private double generateValue(String sensorId) {
        if (sensorId.startsWith("temp")) {
            return Math.round((20 + random.nextDouble() * 15) * 10.0) / 10.0; // 20-35°C
        } else if (sensorId.startsWith("humid")) {
            return Math.round((40 + random.nextDouble() * 50) * 10.0) / 10.0; // 40-90%
        } else if (sensorId.startsWith("soil")) {
            return Math.round((10 + random.nextDouble() * 50) * 10.0) / 10.0; // 10-60%
        }
        return Math.round(random.nextDouble() * 100 * 10.0) / 10.0;
    }
}
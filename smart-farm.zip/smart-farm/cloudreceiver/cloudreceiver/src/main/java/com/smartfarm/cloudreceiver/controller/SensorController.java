package com.smartfarm.cloudreceiver.controller;

import com.influxdb.client.InfluxDBClient;
import com.influxdb.client.QueryApi;
import com.influxdb.query.FluxRecord;
import com.influxdb.query.FluxTable;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/sensors")
public class SensorController {

    private final QueryApi queryApi;

    @Value("${influxdb.bucket}")
    private String bucket;

    @Value("${influxdb.org}")
    private String org;

    public SensorController(InfluxDBClient influxDBClient) {
        this.queryApi = influxDBClient.getQueryApi();
    }

    // GET /sensors/{id}/latest
@GetMapping("/{id}/latest")
    public Map<String, Object> getLatest(@PathVariable String id) {
        String flux = String.format("""
            from(bucket: "%s")
              |> range(start: -24h)
              |> filter(fn: (r) => r._measurement == "sensor_reading")
              |> filter(fn: (r) => r.sensor_id == "%s")
              |> filter(fn: (r) => r._field == "value")
              |> last()
            """, bucket, id);

        List<FluxTable> tables = queryApi.query(flux, org);
        Map<String, Object> result = new HashMap<>();

        for (FluxTable table : tables) {
            for (FluxRecord record : table.getRecords()) {
                result.put("sensor_id", record.getValueByKey("sensor_id"));
                result.put("farm_id", record.getValueByKey("farm_id"));
                result.put("value", record.getValue());
                result.put("unit", record.getValueByKey("unit"));
                result.put("timestamp", record.getTime());
            }
        }

        if (result.isEmpty()) {
            result.put("error", "No data found for sensor: " + id);
        }

        return result;
    }

    // GET /sensors/{id}/readings?from=2026-06-21T00:00:00Z&to=2026-06-22T00:00:00Z
    @GetMapping("/{id}/readings")
    public List<Map<String, Object>> getReadings(
            @PathVariable String id,
            @RequestParam(defaultValue = "-1h") String from,
            @RequestParam(required = false) String to) {

        String range = to != null
            ? String.format("start: %s, stop: %s", from, to)
            : String.format("start: %s", from);

        String flux = String.format("""
            from(bucket: "%s")
              |> range(%s)
              |> filter(fn: (r) => r._measurement == "sensor_reading")
              |> filter(fn: (r) => r.sensor_id == "%s")
              |> filter(fn: (r) => r._field == "value")
              |> sort(columns: ["_time"], desc: false)
            """, bucket, range, id);

        List<FluxTable> tables = queryApi.query(flux, org);
        List<Map<String, Object>> results = new ArrayList<>();

        for (FluxTable table : tables) {
            for (FluxRecord record : table.getRecords()) {
                Map<String, Object> row = new HashMap<>();
                row.put("sensor_id", record.getValueByKey("sensor_id"));
                row.put("farm_id", record.getValueByKey("farm_id"));
                row.put("value", record.getValue());
                row.put("unit", record.getValueByKey("unit"));
                row.put("timestamp", record.getTime());
                results.add(row);
            }
        }
      

        return results;
    }
}
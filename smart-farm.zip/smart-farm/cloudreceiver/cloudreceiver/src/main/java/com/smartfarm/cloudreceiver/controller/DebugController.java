package com.smartfarm.cloudreceiver.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DebugController {
    @Value("${app.role:NOT_SET}")
    private String role;

    @GetMapping("/debug/role")
    public String role() { return "Current role: " + role; }
}
package com.smartfarm.cloudreceiver.service;

import com.influxdb.client.InfluxDBClient;
import com.influxdb.client.WriteApiBlocking;
import com.influxdb.client.domain.WritePrecision;
import com.influxdb.client.write.Point;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
public class PumpControlService {

    private static final Logger log = LoggerFactory.getLogger(PumpControlService.class);

    private final MqttClient mqttClient;
    private final WriteApiBlocking writeApi;

    public PumpControlService(MqttClient mqttClient, InfluxDBClient influxDBClient) {
        this.mqttClient = mqttClient;
        this.writeApi = influxDBClient.getWriteApiBlocking();
    }

    public void setPump(String farmId, boolean on) {
        String command = on ? "pump_on" : "pump_off";
        String topic = "farm/" + farmId + "/control/pump";

        try {
            MqttMessage message = new MqttMessage(command.getBytes());
            message.setQos(1);
            mqttClient.publish(topic, message);
            log.info("Published pump command '{}' to {}", command, topic);

            // Record the command in InfluxDB so Grafana can show pump state
            Point point = Point.measurement("pump_state")
                .addTag("farm_id", farmId)
                .addField("state", on ? 1 : 0)  // 1 = on, 0 = off (numeric for Grafana)
                .time(Instant.now(), WritePrecision.MS);
            writeApi.writePoint(point);

        } catch (MqttException e) {
            log.error("Failed to publish pump command: {}", e.getMessage());
            throw new RuntimeException("Pump control failed", e);
        }
    }
}
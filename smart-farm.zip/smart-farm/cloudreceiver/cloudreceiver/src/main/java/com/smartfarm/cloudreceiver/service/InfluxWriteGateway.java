package com.smartfarm.cloudreceiver.service;

import com.influxdb.client.InfluxDBClient;
import com.influxdb.client.WriteApiBlocking;
import com.influxdb.client.write.Point;
import com.influxdb.client.domain.WritePrecision;
import com.smartfarm.cloudreceiver.model.SensorPayload;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.List;

@Service
public class InfluxWriteGateway {

    private static final Logger log = LoggerFactory.getLogger(InfluxWriteGateway.class);
    private final WriteApiBlocking writeApi;

    public InfluxWriteGateway(InfluxDBClient influxDBClient) {
        this.writeApi = influxDBClient.getWriteApiBlocking();
    }

    @CircuitBreaker(name = "influxdb", fallbackMethod = "writeToDlq")
    public void writeBatch(List<SensorPayload> batch) {
        List<Point> points = batch.stream().map(p ->
            Point.measurement("sensor_reading")
                .addTag("sensor_id", p.getSensorId())
                .addTag("farm_id", p.getFarmId())
                .addField("value", p.getValue())
                .addTag("unit", p.getUnit())
                .time(Instant.now(), WritePrecision.MS)
        ).toList();

        writeApi.writePoints(points);
        log.debug("Wrote {} points to InfluxDB", points.size());
    }

    public void writeToDlq(List<SensorPayload> batch, Exception e) {
        log.error("Circuit breaker open — writing {} messages to DLQ. Cause: {}",
            batch.size(), e.getMessage());
        try {
            String filename = "dlq/failed-" + System.currentTimeMillis() + ".json";
            StringBuilder json = new StringBuilder("[");
            for (int i = 0; i < batch.size(); i++) {
                SensorPayload p = batch.get(i);
                json.append(String.format(
                    "{\"sensor_id\":\"%s\",\"farm_id\":\"%s\",\"value\":%s,\"unit\":\"%s\",\"timestamp\":\"%s\"}",
                    p.getSensorId(), p.getFarmId(), p.getValue(), p.getUnit(), p.getTimestamp()
                ));
                if (i < batch.size() - 1) json.append(",");
            }
            json.append("]");
            Files.writeString(Path.of(filename), json.toString(), StandardOpenOption.CREATE);
            log.info("DLQ file written: {}", filename);
        } catch (IOException ioEx) {
            log.error("Failed to write DLQ file", ioEx);
        }
    }
}